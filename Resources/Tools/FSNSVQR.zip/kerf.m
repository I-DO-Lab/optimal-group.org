function K=kerf(x1,x2,kersign,p)

%SVKERNEL kernel for Support Vector Methods
%
%  Usage: k = svkernel(ker,u,v)
%
%  Parameters: ker - kernel type
%              u,v - kernel arguments
%
%  Values for ker: 'linear'  -
%                  'poly'    - p1 is degree of polynomial
%                  'rbf'     - p1 is width of rbfs (sigma)
%                  'sigmoid' - p1 is scale, p2 is offset
%                  'spline'  -
%                  'bspline' - p1 is degree of bspline
%                  'fourier' - p1 is degree
%                  'erfb'    - p1 is width of rbfs (sigma)
%                  'anova'   - p1 is max order of terms

tmpx=[];
tmpy=[];
if kersign==1
     K=x1*x2';
elseif kersign==2
    [m1,n1]=size(x1);
    [m2,n2]=size(x2);
    K=zeros(m1,m2);
    for i=1:m1
        for j=1:m2
            tmpx=x1(i,:);
            tmpy=x2(j,:);
            K(i,j)=(tmpx*tmpy'+1)^p;      
        end
   end
    
else 
    [m1,n1]=size(x1);
    [m2,n2]=size(x2);
    K=zeros(m1,m2);
    for i=1:m1
        for j=1:m2
            tmpx=x1(i,:); 
            tmpy=x2(j,:);
            K(i,j)=exp(-(tmpx-tmpy)*(tmpx-tmpy)'/(p^2));
        end
     end
end