load('community_data.mat') %tau=0.1,p=2^(3),C=2^(7);tau=0.3,p=2^(2),C=2^(2);tau=0.5,p=2^(2),C=2^(3);tau=0.7,p=2^(2),C=2^(2);tau=0.9,p=2^(5),C=2^(5)
kersign=3; eps=0.01;
tau=0.1;
p=2^(3);C=2^(7);
[wR,L,PredictY,risk]=fsnsvqr(X,Y,TestX,TestY,kersign,p,C,eps,tau);

disp(['feature selection result: ',num2str(L)])
% disp(['prediction result:',num2str(PredictY')])
disp(['R1=',num2str(wR),' risk=',num2str(risk)])