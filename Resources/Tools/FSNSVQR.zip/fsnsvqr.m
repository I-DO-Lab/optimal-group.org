function [wR,L,PredictY,risk]=fsnsvqr(X,Y,TestX,TestY,kersign,p,C,eps,tau)
[m,n]=size(X); 
e=ones(m,1);
Z=eye(n);
tol=10^(-7);

%%%init 
X=X*Z;
G=kerf(X,X,kersign,p);
H=[G -G;
  -G G];
f = [(eps*(1-tau)*ones(m,1) - Y); (eps*(tau)*ones(m,1) + Y)];  
Aeq=[ones(1,m) -ones(1,m)];
beq=0;
lb=zeros(2*m);
ub=[C*(tau)*ones(m);C*(1-tau)*ones(m)];
x0=zeros(2*m);
tic
alpha=quadprog(H,f,[],[],Aeq,beq,lb,ub);
toc
beta0= alpha(1:m) - alpha(m+1:2*m);
sum0=beta0'*G*beta0;
Value=zeros(n,1);
Score=zeros(n,1);
z=zeros(n,n);
for i=1:n
   z(i,i)=1;
   GZ=kerf(X*z,X*z,kersign,p);
   Value(i)=abs(beta0'*GZ*beta0);
   z(i,i)=0;
end

for i=1:n
 Score(i)=Value(i)/sum(Value');
   if Score(i)>= 1/(n)
        Z(i,i)=1;
    else
        Z(i,i)=0;
   end
end 

%%%solve Z
warning('off');
options = optimoptions('quadprog', 'Display', 'none');

for l=1:50
X=X*Z;
G=kerf(X,X,kersign,p);
H=[G -G;
  -G G];
f = [(eps*(1-tau)*ones(m,1) - Y); (eps*(tau)*ones(m,1) + Y)];  
Aeq=[ones(1,m) -ones(1,m)];
beq=0;
lb=zeros(2*m);
ub=[C*(tau)*ones(m);C*(1-tau)*ones(m)];
x0=zeros(2*m);
tic
alpha=quadprog(H,f,[],[],Aeq,beq,lb,ub,[],options);
toc
beta= alpha(1:m) - alpha(m+1:2*m);
sum1=beta'*G*beta;
Value=zeros(n,1);
Score=zeros(n,1);
z=zeros(n,n);
for i=1:n
   z(i,i)=1;
   GZ=kerf(X*z,X*z,kersign,p);
   Value(i)=abs(beta'*GZ*beta);
   z(i,i)=0;
end

for i=1:n
   Score(i)=Value(i)/sum(Value');
   if Score(i)>= 1/(n) %
        Z(i,i)=1;
    else
        Z(i,i)=0;
   end
end 

if abs(sum1-sum0)< tol
    break
else
    sum0=sum1;

end
end

L=zeros(n,1);
for i=1:n
    L(i,1)=Z(i,i);
end

%%% feature selection
FV=sum(eig(Z))
NX=zeros(m,FV);
j=1;
for i=1:n
    if Z(i,i)~=0
          NX(:,j)=X(:,i);
          j=j+1;
    else
        j=j;
    end 
end


G=kerf(NX,NX,kersign,p);
H=[G -G;
  -G G];
f = [(eps*(1-tau)*ones(m,1) - Y); (eps*(tau)*ones(m,1) + Y)];  
Aeq=[ones(1,m) -ones(1,m)];
beq=0;
lb=zeros(2*m);
ub=[C*(tau)*ones(m);C*(1-tau)*ones(m)];
x0=zeros(2*m);
tic
alpha=quadprog(H,f,[],[],Aeq,beq,lb,ub,[],options);
toc
beta= alpha(1:m) - alpha(m+1:2*m);
epsilon = svtol(C);

%Compute the number of Support Vectors
svi = find( abs(beta) > epsilon );
nsv = length( svi );

svii = find( abs(beta) > epsilon & abs(beta) < (C - epsilon));
         if length(svii) > 0
            bias = prctile(Y(svii) - eps*sign(beta(svii)) - G(svii,svi)*beta(svi),tau*100);
          else 
            fprintf('No support vectors with interpolation error e - cannot compute bias.\n');
            bias = (max(Y)+min(Y))/2;
         end
L=L';
          
m1=size(TestX,1);        
e1=ones(size(TestX,1),1);
TNX=zeros(m1,FV);
j=1;
for i=1:n
    if Z(i,i)~=0
          TNX(:,j)=TestX(:,i);
          j=j+1;
    else
        j=j;
    end 
end


K=kerf(TNX,NX,kersign,p);
PredictY=K*beta+bias*e1;
ppp=prctile(TestY,tau*100);
a=TestY>=PredictY;
b=TestY>=ppp;
v1=sum(tau*a.*(TestY-PredictY)+(1-tau)*(a-1).*(TestY-PredictY));
risk=mean(tau*a.*(TestY-PredictY)+(1-tau)*(a-1).*(TestY-PredictY));
v0=sum(tau*b.*(TestY-ppp)+(1-tau)*(b-1).*(TestY-ppp));
wR=1-v1/v0;

end